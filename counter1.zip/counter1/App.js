import {StatusBar} from 'expo-status-bar';
import * as React from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';

export default class App extends React.Component {
  state = {
    value: 0,
    total_taps: 0,
  }

  incrementValue = () => {
    this.setState({
      value: this.state.value + 1,
      total_taps: this.state.total_taps + 1,
    })
    console.log('Value: ' + (this.state.value + 1));
  }

  decrementValue = () => {
    this.setState ({
      value: this.state.value - 1,
      total_taps: this.state.total_taps - 1
    })
    console.log('Value: ' + (this.state.value - 1));
  }

  render () 
  {
    return (
      <View style = {styles.container}>
      <Text style = {{ fontSize: 60, marginBottom: -20}}> {this.state.value} </Text>
      <Text style = {{ fontSize: 12, padding: 20, color: 'white'}}> {"Total taps: " + this.state.total_taps}
      </Text>
      <StatusBar style = "auto" />
      <View style = {{flexDirection: 'row'}}>
      <Button onPress = {this.decrementValue} title = "-" />
      <Text> </Text>
      <Button onPress = {this.incrementValue} title = "+" />
      </View>
      </View>
      );
  }
}
const styles = StyleSheet.create ({
  container: {
    flex: 1,
    backgroundColor: '#B0E0E6',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
